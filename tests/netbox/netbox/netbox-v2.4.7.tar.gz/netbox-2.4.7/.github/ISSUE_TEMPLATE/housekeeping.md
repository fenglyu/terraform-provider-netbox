---
name: 🏡 Housekeeping
about: A change pertaining to the codebase itself

---

<!--
    NOTE: This type of issue should be opened only by those reasonably familiar
    with NetBox's code base and interested in contributing to its development.

    Describe the proposed change(s) in detail.
-->
### Proposed Changes


<!-- Provide justification for the proposed change(s). -->
### Justification
