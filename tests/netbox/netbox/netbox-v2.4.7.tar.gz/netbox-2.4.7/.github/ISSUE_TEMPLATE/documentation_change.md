---
name: 📖 Documentation Change
about: Suggest an addition or modification to the NetBox documentation

---

<!--
    Please indicate the nature of the change by placing an X in one of the
    boxes below.
-->
### Change Type
[ ] Addition
[ ] Correction
[ ] Deprecation
[ ] Cleanup (formatting, typos, etc.)

<!-- Describe the proposed change(s). -->
### Proposed Changes
